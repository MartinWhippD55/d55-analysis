---
name: jira-tree
description: Render a spec-to-stories decomposition into an editable filesystem mirror of the Jira issue hierarchy and enrich the descriptions. Stage 3 of the spec-to-Jira pipeline.
inclusion: manual
---

# Jira Tree

Turn a spec-to-stories decomposition into an **editable filesystem mirror** of the
Jira issue hierarchy — an `epic.md`, a `story.md` per user story, a file per
sub-task, and a `_links.md` of the cross-story "blocks" links — then **iterate on the
content locally** and **push it to Jira** once you're happy.

This is the review-and-enrich step between `jira-plan.json` and live Jira.
`decomposition-to-jira` pushes the auto-generated plan straight to Jira with thin
descriptions; **jira-tree** inserts a human-editable surface first: each issue's
markdown body *is* its Jira description, so you can enrich, diff and review it in a PR
before anything lands.

Like its siblings this is a **hybrid skill**: a small **deterministic engine** renders
/ parses / validates the tree. Authoring (generate → enrich → validate) lives here;
the actual push to live Jira is handed off to the **jira-push** skill (see step 4).
The engine never touches Jira.

## Self-sufficient bundle

```
.kiro/skills/jira-tree/
  SKILL.md                 this file
  USER-README.md           user-facing guide
  requirements.txt         pyyaml, hypothesis, pytest
  engine/
    tree.py                build_tree_from_plan, write_tree, load_tree,
                           validate_tree, find_placeholders, summarize, load_plan
  templates/
    epic.md.tmpl           canonical Epic description shape + house style
    story.md.tmpl          canonical Story description shape + house style
    subtask.md.tmpl        canonical Sub-task description shape + house style
  tests/
    test_tree.py           seed mapping, round-trip, non-destructive write,
                           validation, placeholders, determinism (property-based)
```

Run the engine from the bundle root (`python -m pytest`, or import `engine.tree`).

## Where the tree lives

Default location, alongside the decomposition it mirrors:

```
.kiro/specs/<parent>/decomposition/jira-tree/
  epic.md            _links.md          README.md
  US-01/ story.md + <US-01-n>.md ...    US-02/ ...
```

Folder nesting *is* the parent/child hierarchy: epic at root, each story a folder,
sub-tasks leaf files inside it. Sub-tasks are named by key (`US-01-1.md`) so they sort
naturally.

## The mapping

| Tree | Jira |
|------|------|
| `epic.md` | Epic |
| `<US-xx>/story.md` | Story under the epic |
| `<US-xx>/<US-xx-n>.md` | Sub-task under that story |
| `_links.md` entry `outward -> inward` | "Blocks" link: **outward blocks inward** (outward ships first) |

**Frontmatter = Jira fields, body = description.** Frontmatter carries `issue_type`,
`summary`, `identity_label`, `labels`, and (per type) `parent`/`parent_epic`,
`requirements`/`covers_requirements`, `estimate_days`, `wave`, `depends_on`, `blocks`,
`optional`. The markdown **body** is the issue description, read verbatim on load.

**Idempotency** is by stable identity label, copied straight through from the plan:
epic `s2s-<parent>-epic`, story `s2s-<parent>-US-01`, sub-task `s2s-<parent>-US-01-1`,
plus the set label `s2s-<parent>` on everything. A push searches the identity label
before creating, so re-running never duplicates. This matches `decomposition-to-jira`
exactly.

## Description templates & house style

Each issue type has a canonical description shape in `templates/*.md.tmpl`.
`build_tree_from_plan` **seeds bodies in these shapes** and leaves clearly-marked
`TODO` placeholders where content must be enriched. The templates are the reference
an author or sub-agent targets.

**House style — clear and easy to read (borrowed from ultra-terse writing, minus the
persona):**

- Lead with substance. No preamble, no hedging, no "this task involves…".
- Short sentences and bullets. Spell things out; do not invent abbreviations.
- Keep code, API names, CLI commands and error strings **verbatim**.
- Expand where order or ambiguity matters — never compress a multi-step sequence into
  a fragment that could be misread.

**Per type:**

- **Epic** — Goal · Background · Scope · Delivery-plan table · Story index · Definition
  of done. The delivery plan and story index are seeded from the plan (we have all
  stories + waves); goal/background/scope are placeholders.
- **Story** — user-story line → Description → Delivers → **Acceptance criteria in
  Given/When/Then** → Dependencies (named `US-xx — summary`) → Traceability. User
  story, dependencies and traceability are seeded; description, delivers and AC are
  placeholders.
- **Sub-task** — greppable **What / Why / Done-when** bullets, then a **Suggested
  approach** code fence (a small, honest starting point a developer can run with:
  handler stub, CDK snippet, request/response JSON, component mock). `What` and
  requirement refs are seeded; `Why`, `Done-when` and the snippet are placeholders.
  An API response shape here should match the OpenAPI spec, and a component mock should
  match its backing endpoint — mismatches surface gaps in the parent spec.

### Optional: enrich with a sub-agent (iterative)

After seeding, an optional enrichment pass fills the placeholders — most usefully the
sub-task **Suggested approach** snippets and story **acceptance criteria** — by reading
the spec's `design.md`/`requirements.md`, any OpenAPI spec, and (if pointed at one) an
associated code repository.

Enrichment is **iterative, not one-shot**. A freshly seeded tree can carry a `TODO` in
almost every issue (e.g. 55 across one epic + 10 stories + 44 sub-tasks); a single pass
over all of them produces shallow, inconsistent bodies. Work in **batches** and **loop
until done**:

1. **Establish the baseline.** Run `find_placeholders(tree)` and record the count and
   which issues still carry a `TODO`. This is the worklist.
2. **Batch by story.** Take one story and its sub-tasks as a unit (the story's
   acceptance criteria and its sub-tasks' snippets share context). Dispatch batches to
   sub-agents — up to ~5 concurrently — rather than one agent over the whole tree.
   Each sub-agent must:
   - Replace `TODO` markers **only**; preserve all frontmatter and identity labels.
   - Read the spec's `design.md`/`requirements.md`, the OpenAPI spec, and any pointed-to
     repo for that story's area before writing.
   - Flag any cross-reference mismatch (e.g. a mock whose shape disagrees with the
     OpenAPI response) as a candidate spec gap in its report — do **not** silently
     "fix" the spec.
3. **Re-check after each round.** Re-run `validate_tree` (must stay `[]`) and
   `find_placeholders` (count must **strictly decrease**). Record the new worklist.
4. **Repeat** from step 2 with the remaining placeholders until `find_placeholders`
   returns empty, or every remaining `TODO` is one you have **deliberately** chosen to
   leave (note which, and why). Do not stop early with unexplained placeholders.
5. **Guard against stalls.** If a round doesn't reduce the count, or a sub-agent can't
   fill a placeholder because the source spec is silent, stop and surface it — that is a
   spec gap for the user, not something to invent an answer for.

The loop's stop condition is explicit: `find_placeholders` empty (or a documented,
intentional remainder) **and** `validate_tree == []`.

## Prerequisites

- A `jira-plan.json` for the spec (produced by **decomposition-to-jira**'s
  `build_plan`/`write_plan`) at `.kiro/specs/<parent>/decomposition/jira-plan.json`.
  If it doesn't exist, run **decomposition-to-jira** step 1 first.
- For the push: the **Atlassian Jira MCP** connected (tool prefix
  `mcp_atlassian_jira_*`). Sanity-check with a read call
  (e.g. `jira_get_all_projects`) before writing anything. If
  disconnected, ensure `.kiro/settings/atlassian.env` holds a valid token and
  reconnect the `atlassian` server from the Kiro MCP panel.
- A **target project key**. Ask the user. Trial against **`TEST`** (Bryt MSP Project)
  before any real project (e.g. **`BRYT`**), and only on explicit confirmation.

## Steps

### 1. Generate the tree from the plan (deterministic, non-destructive)

```python
from engine.tree import load_plan, build_tree_from_plan, write_tree, summarize
plan = load_plan(".kiro/specs/<parent>/decomposition/jira-plan.json")
tree = build_tree_from_plan(plan)
written = write_tree(tree, ".kiro/specs/<parent>/decomposition/jira-tree")  # overwrite=False
print(summarize(tree), f"— wrote {len(written)} new files")
```

`write_tree` **skips files that already exist** (`overwrite=False` default), so
regenerating never clobbers hand-edited descriptions. Only pass `overwrite=True` to
deliberately reset a file to its seeded content.

### 2. Iterate locally

Enrich the markdown **bodies** to the house style above — replace every `TODO`
placeholder (acceptance criteria, delivers, suggested-code snippets, notes). Leave
frontmatter and identity labels intact. Run the **sub-agent enrichment** pass to draft
the snippets and criteria — this is **iterative**: batch by story, loop until
`find_placeholders` is empty (or the remainder is intentional) and `validate_tree`
stays `[]`. See "Optional: enrich with a sub-agent (iterative)" above for the loop and
its stop condition. Commit and review in a PR like any other file — this is the whole
point of the tree.

### 3. Load and validate before pushing

```python
from engine.tree import load_tree, validate_tree, find_placeholders, summarize
tree = load_tree(".kiro/specs/<parent>/decomposition/jira-tree")
problems = validate_tree(tree)
assert not problems, problems
todos = find_placeholders(tree)   # soft check: any un-enriched TODO placeholders
print(summarize(tree), f"— {len(todos)} issues still have TODO placeholders")
```

`validate_tree` returns `[]` when the tree is internally consistent. It flags: missing
/ malformed / duplicate identity labels; a story whose `parent_epic` doesn't match the
epic; `blocks`/`depends_on`/link endpoints that don't resolve to a known story;
sub-task `parent` mismatches; `optional` flag vs `optional` label disagreements; and
any disagreement between `_links.md` and the per-story `blocks:` frontmatter. **Do not
push a tree with problems** — fix them first.

`find_placeholders` is a **soft** check — it lists issues whose body still has a `TODO`.
It doesn't block a push, but surface the count to the user: pushing placeholder text
into Jira is rarely intended. Show the summary + placeholder count + target project and
get a go-ahead (writes are **not** auto-approved).

### 4. Push to Jira — hand off to **jira-push**

Once the tree is enriched and `validate_tree` is `[]`, the actual push to live Jira is
owned by the **jira-push** skill (`.kiro/skills/jira-push/`). It loads this tree,
builds an ordered, idempotent push plan (epic → stories → sub-tasks → links),
reconciles it against what already exists in Jira, and creates only what's missing —
reusing issues by identity label and skipping links that already exist.

Follow `.kiro/skills/jira-push/SKILL.md`. In short:

```python
from engine.push import load_tree_view, build_push_plan, validate_plan, reconcile, summarize_plan
tree, problems = load_tree_view(".kiro/specs/<parent>/decomposition/jira-tree")
assert not problems, problems
plan = build_push_plan(tree)
assert not validate_plan(plan), validate_plan(plan)
print(summarize_plan(reconcile(plan)))   # dry summary before any Jira write
```

Then confirm the project/issue types, reconcile against existing issues+links, and
execute the plan (epic first, each story before its sub-tasks, links last). Same
idempotency-by-label and sandbox-`TEST`-first rules apply — writes are **not**
auto-approved. jira-push returns the created/reused keys.

## Verify

- `python -m pytest` in the bundle (engine correctness — seed mapping, round-trip,
  non-destructive write, validation, placeholders, determinism).
- `load_tree` then `validate_tree` on the real tree must return `[]` before a push;
  `find_placeholders` should ideally be empty (or the remaining `TODO`s are intended).
- After a push, spot-check in Jira (or `jira_get_issue <epicKey>`,
  `jira_search labels = "<set_label>"`) that the epic, stories and sub-tasks exist,
  descriptions match the edited bodies, stories link to the epic, and blocks-links
  point dependency → dependent.
- Re-run against the same project and confirm nothing is duplicated (idempotency).

## Format note

Jira stores descriptions as ADF/wiki markup, not markdown. The Atlassian MCP converts
the markdown body on create, so headings, lists and tables render; mermaid blocks and
exotic markdown may not. The tree is a human-review mirror, not a byte-for-byte Jira
export.

## Hard rules

- **Round-trip safe.** `load_tree` reads the body verbatim as the description; edits
  are never lost. `write_tree` is non-destructive by default — never clobber edits.
- **Validate before push.** A tree with `validate_tree` problems must not be pushed.
- **Read before write.** Sanity-check the MCP with a read call, and always search by
  identity label before creating — never create blind.
- **Sandbox first.** Trial against `TEST`; only touch a real project on explicit
  user confirmation.
- **Idempotent.** Identity labels are the dedupe key; re-running must not duplicate
  issues or links.
- **Never emit secrets.** The Jira token lives only in `.kiro/settings/atlassian.env`
  (git-ignored). Nothing this skill writes or prints may contain it.
- **Faithful.** One epic, one story per `US-xx`, one sub-task per sub-task, one
  blocks-link per edge — no more, no less.
